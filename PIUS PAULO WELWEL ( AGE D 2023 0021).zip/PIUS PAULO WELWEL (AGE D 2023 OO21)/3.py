
rainfall = [10.2, 0.0, 5.5, 1.2, 8.0, 0.0, 3.5]
total_rainfall = sum(rainfall)


no_rainfall_days = []
for i, measurement in enumerate(rainfall):
    
    if measurement == 0.0:
        
        no_rainfall_days.append(f"Day {i + 1}")


print(f"Total weekly rainfall: {total_rainfall:.1f} mm")
if no_rainfall_days:
    print("Days with no rainfall:", ", ".join(no_rainfall_days))
else:
    print("All days had some rainfall.")

