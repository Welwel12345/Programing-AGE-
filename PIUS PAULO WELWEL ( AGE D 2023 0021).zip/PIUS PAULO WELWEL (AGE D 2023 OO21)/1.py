
yield_data = [3.5, 4.2, 3.9, 4.5, 5.1, 4.8, 5.5, 5.3, 5.8, 6.2]

print("Maize Yield Data for the past ten years (in tonnes):", yield_data)
print("-" * 50)
total_yield = sum(yield_data)
number_of_years = len(yield_data)
average_yield = total_yield / number_of_years

print(f"1. Average Yield: {average_yield:.2f} tonnes") 


highest_yield = max(yield_data)
lowest_yield = min(yield_data)


year_highest_yield_index = yield_data.index(highest_yield)
year_lowest_yield_index = yield_data.index(lowest_yield)


print(f"2. Highest Yield: {highest_yield} tonnes (occurred in Year {year_highest_yield_index + 1})")
print(f"   Lowest Yield: {lowest_yield} tonnes (occurred in Year {year_lowest_yield_index + 1})")


years_above_5_tonnes = 0


for yield_value in yield_data:
    
    if yield_value > 5.0:
        years_above_5_tonnes += 1 

print(f"3. Number of years the yield was above 5.0 tonnes: {years_above_5_tonnes}")
