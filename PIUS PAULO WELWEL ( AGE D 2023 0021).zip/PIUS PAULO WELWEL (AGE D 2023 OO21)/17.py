
class Crop:
    def planting_instructions(self):
        print("General planting instructions.")
class CerealCrop(Crop):
    def __init__(self, grain_type):
        self.grain_type = grain_type
class LegumeCrop(Crop):
    def __init__(self, nitrogen_fixing):
        self.nitrogen_fixing = nitrogen_fixing
cereal = CerealCrop("Wheat")
legume = LegumeCrop(True)
print(f"Cereal Grain: {cereal.grain_type}")
print(f"Legume Nitrogen Fixing: {legume.nitrogen_fixing}")
