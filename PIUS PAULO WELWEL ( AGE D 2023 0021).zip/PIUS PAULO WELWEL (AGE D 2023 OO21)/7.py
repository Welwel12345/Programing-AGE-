def get_item_quantity(inventory, item_name):

  if item_name in inventory:
    return inventory[item_name]
  else:
    return "Item not found"
farm_inventory = {
    'Tractor': 1,
    'Plough': 2,
    'Seeds': 150,  
    'Fertilizer': 50,
    'Shovel': 5
}
item_to_check_1 = 'Seeds'
quantity_1 = get_item_quantity(farm_inventory, item_to_check_1)
print(f"Quantity of '{item_to_check_1}': {quantity_1}")
item_to_check_2 = 'Tractor'
quantity_2 = get_item_quantity(farm_inventory, item_to_check_2)
print(f"Quantity of '{item_to_check_2}': {quantity_2}")


item_to_check_3 = 'Pesticides'
quantity_3 = get_item_quantity(farm_inventory, item_to_check_3)
print(f"Quantity of '{item_to_check_3}': {quantity_3}")


item_to_check_4 = 'tractor'
quantity_4 = get_item_quantity(farm_inventory, item_to_check_4)
print(f"Quantity of '{item_to_check_4}': {quantity_4}")
