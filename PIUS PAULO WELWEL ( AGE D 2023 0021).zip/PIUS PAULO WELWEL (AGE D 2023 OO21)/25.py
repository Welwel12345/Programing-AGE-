class Plant:
    def harvest(self):
        print("General plant harvest.")
class FruitTree(Plant):
    def harvest(self):
        print("Harvesting fruits carefully.")
class RootVegetable(Plant):
    def harvest(self):
        print("Harvesting root vegetable from soil.")
plants = [FruitTree(), RootVegetable()]
for plant in plants:
    plant.harvest()

