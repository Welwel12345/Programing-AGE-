class Pest:
    def damage_report(self):
        return "General pest damage."
class InsectPest(Pest):
    def damage_report(self):
        return "Insect: Leaf damage."
class FungalPest(Pest):
    def damage_report(self):
        return "Fungus: Root rot."
class CropWithPests:
    def __init__(self, name):
        self.name = name
        self.pests = []
    def add_pest(self, pest):
        self.pests.append(pest)
    def generate_pest_report(self):
        for pest in self.pests:
            print(pest.damage_report())
maize = CropWithPests("Maize")
maize.add_pest(InsectPest())
maize.add_pest(FungalPest())
maize.generate_pest_report()