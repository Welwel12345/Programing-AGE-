

class FarmAnimal:
    
    
    def __init__(self, name, species):
       
        self.name = name
        self.species = species

    def __str__(self):
        
        return f"{self.name} ({self.species})"

class Crop:
    
    def __init__(self, name, crop_type, planting_date):
     
        self.name = name
        self.crop_type = crop_type
        self.planting_date = planting_date

    def __str__(self):
    
        return f"{self.name} ({self.crop_type}, planted: {self.planting_date})"

class Farm:
 
    def __init__(self, name):
  
        self.name = name
        self.animals = []  
        self.crops = {}    
        print(f"Farm '{self.name}' has been established.")

    def add_animal(self, animal):
 
        if not isinstance(animal, FarmAnimal):
            print(f"Error: {animal} is not a valid FarmAnimal object.")
            return

        self.animals.append(animal)
        print(f"Added {animal.name} the {animal.species} to {self.name}.")

    def plant_crop(self, field_name, crop):
    
        if not isinstance(crop, Crop):
            print(f"Error: {crop} is not a valid Crop object.")
            return

        self.crops[field_name] = crop
        print(f"Planted {crop.name} in field '{field_name}' on {self.name}.")

    def get_daily_report(self):
        
        print(f"\n--- Daily Report for {self.name} ---")

       
        total_animals = len(self.animals)
        print(f"Total animals on the farm: {total_animals}")
        if total_animals > 0:
            print("Animals:")
            for animal in self.animals:
                print(f"  - {animal}")
        else:
            print("  No animals currently on the farm.")


     
        print("\nCrops being grown:")
        if self.crops:
            for field_name, crop in self.crops.items():
                print(f"  Field '{field_name}': {crop}")
        else:
            print("  No crops are currently planted.")

        print("------------------------------------\n")


if __name__ == "__main__":
   
    my_farm = Farm("Green Valley Farm")

 
    cow = FarmAnimal("Bessie", "Cow")
    chicken = FarmAnimal("Clucky", "Chicken")
    pig = FarmAnimal("Wilbur", "Pig")

  
    my_farm.add_animal(cow)
    my_farm.add_animal(chicken)
    my_farm.add_animal(pig)

   
    wheat = Crop("Wheat", "Grain", "2025-06-01")
    corn = Crop("Corn", "Grain", "2025-05-20")
    carrots = Crop("Carrots", "Vegetable", "2025-06-10")

 
    my_farm.plant_crop("North Field", wheat)
    my_farm.plant_crop("South Field", corn)
    my_farm.plant_crop("Garden Plot", carrots)

    
    my_farm.get_daily_report()

    
    sheep = FarmAnimal("Shaun", "Sheep")
    my_farm.add_animal(sheep)
    my_farm.get_daily_report()

    my_farm.add_animal("Not an animal")
    my_farm.plant_crop("Invalid Field", "Not a crop")
