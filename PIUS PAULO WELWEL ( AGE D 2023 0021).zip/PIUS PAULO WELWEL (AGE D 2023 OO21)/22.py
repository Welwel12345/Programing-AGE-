class Livestock:
    def feed(self):
        print("Feeding generic livestock.")
class Cow(Livestock):
    def feed(self):
        print("Cow is eating hay.")
class Chicken(Livestock):
    def feed(self):
        print("Chicken is pecking grains.")
animals = [Cow(), Chicken()]
for animal in animals:
    animal.feed()
