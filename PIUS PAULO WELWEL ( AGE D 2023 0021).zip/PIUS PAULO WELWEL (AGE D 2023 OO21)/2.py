
rates = [120, 150, 100, 180, 130]

cost_per_kg = 1500


total_costs = []


for rate in rates:
    
    cost_for_field = rate * cost_per_kg

    
    total_costs.append(cost_for_field)


print("Total fertilizer cost for each field (TZS):")
print(total_costs)

