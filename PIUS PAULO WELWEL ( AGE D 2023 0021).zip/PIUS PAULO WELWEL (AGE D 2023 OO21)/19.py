
import abc
import random


class AgriculturalSensor(abc.ABC):
    

    @abc.abstractmethod
    def read_data(self):
        
        pass


class SoilMoistureSensor(AgriculturalSensor):
    

    def read_data(self):
       
        simulated_moisture = random.uniform(0.0, 100.0)
        print(f"Soil Moisture Sensor reading: {simulated_moisture:.2f}%")
        return simulated_moisture

class AirTemperatureSensor(AgriculturalSensor):
   

    def read_data(self):
       
        simulated_temperature = random.uniform(-10.0, 50.0)
        print(f"Air Temperature Sensor reading: {simulated_temperature:.2f}°C")
        return simulated_temperature

if __name__ == "__main__":
    print("--- Demonstrating Agricultural Sensors ---")

   
    soil_sensor = SoilMoistureSensor()
    temp_sensor = AirTemperatureSensor()

  
    print("\nReading data from sensors:")
    moisture_reading = soil_sensor.read_data()
    temp_reading = temp_sensor.read_data()

    
    sensors = [SoilMoistureSensor(), AirTemperatureSensor()]
    print("\nReading data from a list of sensors:")
    for sensor in sensors:
        sensor.read_data()
