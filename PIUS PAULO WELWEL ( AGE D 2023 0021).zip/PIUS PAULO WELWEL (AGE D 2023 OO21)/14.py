class SoilSample:
   

    def __init__(self, sample_id: str, ph_level: float, organic_matter_content: float):
       
        self.sample_id = sample_id
        self.ph_level = ph_level
        self.organic_matter_content = organic_matter_content

    def get_fertility_status(self) -> str:
      
        ph_condition_met = 6.0 <= self.ph_level <= 7.0

        
        organic_matter_condition_met = self.organic_matter_content > 2.5

        if ph_condition_met and organic_matter_condition_met:
            return 'High'
        elif ph_condition_met or organic_matter_condition_met:
            return 'Medium'
        else:
            return 'Low'

if __name__ == "__main__":
    
    sample1 = SoilSample("S001", 6.5, 3.0)  
    sample2 = SoilSample("S002", 7.2, 1.5)  
    sample3 = SoilSample("S003", 6.8, 2.0)  
    sample4 = SoilSample("S004", 5.5, 3.5)  
    sample5 = SoilSample("S005", 6.0, 2.5)  

    print(f"Sample {sample1.sample_id} fertility status: {sample1.get_fertility_status()}")
    print(f"Sample {sample2.sample_id} fertility status: {sample2.get_fertility_status()}")
    print(f"Sample {sample3.sample_id} fertility status: {sample3.get_fertility_status()}")
    print(f"Sample {sample4.sample_id} fertility status: {sample4.get_fertility_status()}")
    print(f"Sample {sample5.sample_id} fertility status: {sample5.get_fertility_status()}")
