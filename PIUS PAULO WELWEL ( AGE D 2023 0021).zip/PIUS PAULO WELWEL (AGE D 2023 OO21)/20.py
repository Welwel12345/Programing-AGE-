class Livestock:
    def __init__(self, species, weight):
        self.species = species
        self.weight = weight
class Cattle(Livestock):
    def calculate_feed_ratio(self):
        return self.weight * 0.02
class Poultry(Livestock):
    def calculate_feed_ratio(self):
        return self.weight * 0.05
print(f"Cattle Feed Ratio: {Cattle('Cow', 500).calculate_feed_ratio()} kg/day")
print(f"Poultry Feed Ratio: {Poultry('Chicken', 2).calculate_feed_ratio()} kg/day")

