
student_data = {
    "AGE219/001": {
        "name": "Alice Smith",
        "assignment_scores": [85, 90, 78, 92]
    },
    "AGE219/002": {
        "name": "Bob Johnson",
        "assignment_scores": [70, 75, 68, 80]
    },
    "AGE219/003": {
        "name": "Charlie Brown",
        "assignment_scores": [95, 88, 91, 87]
    },
    "AGE219/004": {
        "name": "Diana Prince",
        "assignment_scores": [60, 65, 70, 55]
    }
}

def calculate_average_score(reg_number: str) -> float | str:
   
    if reg_number in student_data:
        student = student_data[reg_number]
        scores = student["assignment_scores"]

        
        if scores:
            
            average = sum(scores) / len(scores)
            return average
        else:
            return f"No assignment scores found for student {student['name']} ({reg_number})."
    else:
        return f"Student with registration number {reg_number} not found."



print("--- Calculating Student Averages ---")


reg_num_alice = "AGE219/001"
average_alice = calculate_average_score(reg_num_alice)
if isinstance(average_alice, float):
    print(f"The average score for {student_data[reg_num_alice]['name']} ({reg_num_alice}) is: {average_alice:.2f}")
else:
    print(average_alice)


reg_num_bob = "AGE219/002"
average_bob = calculate_average_score(reg_num_bob)
if isinstance(average_bob, float):
    print(f"The average score for {student_data[reg_num_bob]['name']} ({reg_num_bob}) is: {average_bob:.2f}")
else:
    print(average_bob)


reg_num_invalid = "AGE219/999"
average_invalid = calculate_average_score(reg_num_invalid)
print(average_invalid)


student_data["AGE219/005"] = {
    "name": "Eve Adams",
    "assignment_scores": []
}
reg_num_eve = "AGE219/005"
average_eve = calculate_average_score(reg_num_eve)
print(average_eve)


student_data["AGE219/006"] = {
    "name": "Frank White",
    "assignment_scores": [77, 81, 79]
}
reg_num_frank = "AGE219/006"
average_frank = calculate_average_score(reg_num_frank)
if isinstance(average_frank, float):
    print(f"The average score for {student_data[reg_num_frank]['name']} ({reg_num_frank}) is: {average_frank:.2f}")
else:
    print(average_frank)
