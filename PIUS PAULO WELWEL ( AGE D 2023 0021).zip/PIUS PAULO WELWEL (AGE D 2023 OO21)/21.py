
class FarmVehicle:
    def start_engine(self):
        print("Engine started.")
class Tractor(FarmVehicle):
    def start_engine(self):
        print("Tractor engine rumbles to life.")
class CombineHarvester(FarmVehicle):
    def start_engine(self):
        print("Harvester engine whirs loudly.")
vehicles = [Tractor(), CombineHarvester()]
for vehicle in vehicles:
    vehicle.start_engine()
