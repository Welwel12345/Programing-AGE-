fuel_log = [45.5, 52.0, 48.3, 42.1, 55.6]
price_per_liter = 2800  

total_consumption = sum(fuel_log)
total_cost = total_consumption * price_per_liter

print(f"Total fuel consumption: {total_consumption:.2f} liters")
print(f"Total fuel cost: {total_cost:.2f} TZS")