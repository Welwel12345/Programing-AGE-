class Machine:
    def perform_maintenance(self):
        print("General machine maintenance.")
class WaterPump(Machine):
    def perform_maintenance(self):
        print("Water Pump: Checking seals and filter.")
class Generator(Machine):
    def perform_maintenance(self):
        print("Generator: Changing oil.")
def service_machine(machine):
    machine.perform_maintenance()
service_machine(WaterPump())
service_machine(Generator())
