from abc import ABC, abstractmethod
class WaterSource(ABC):
    @abstractmethod
    def get_water(self, liters): pass
class Borehole(WaterSource):
    def __init__(self, max_extraction):
        self.max_extraction = max_extraction
    def get_water(self, liters):
        if liters > self.max_extraction:
            return "Limit exceeded."
        return f"Extracted {liters} liters."
class River(WaterSource):
    def __init__(self, flow_rate):
        self.flow_rate = flow_rate
    def get_water(self, liters):
        return f"Extracted {liters} liters at {self.flow_rate} L/min."
print(Borehole(10000).get_water(8000))
print(River(500).get_water(5000))
