class IrrigationPump:
   

    def __init__(self, pump_type: str, flow_rate_lpm: float):

        self.pump_type = pump_type
        self.flow_rate = flow_rate_lpm  

    def calculate_water_pumped(self, time_hours: float) -> float:
 
        if time_hours <= 0:
            print("Time must be a positive value.")
            return 0.0

      
        time_minutes = time_hours * 60

       
        total_liters = self.flow_rate * time_minutes

    
        total_cubic_meters = total_liters / 1000

        return total_cubic_meters


if __name__ == "__main__":
    
    my_pump = IrrigationPump(pump_type="Centrifugal", flow_rate_lpm=500.0)

    print(f"Pump Type: {my_pump.pump_type}")
    print(f"Flow Rate: {my_pump.flow_rate} liters/minute")

    
    hours_to_pump = 3
    water_pumped = my_pump.calculate_water_pumped(hours_to_pump)
    print(f"Water pumped in {hours_to_pump} hours: {water_pumped:.2f} cubic meters")

    
    hours_to_pump_2 = 0.5
    water_pumped_2 = my_pump.calculate_water_pumped(hours_to_pump_2)
    print(f"Water pumped in {hours_to_pump_2} hours: {water_pumped_2:.2f} cubic meters")

   
    submersible_pump = IrrigationPump(pump_type="Submersible", flow_rate_lpm=1200.0)
    hours_to_pump_3 = 24 
    water_pumped_3 = submersible_pump.calculate_water_pumped(hours_to_pump_3)
    print(f"\nPump Type: {submersible_pump.pump_type}")
    print(f"Flow Rate: {submersible_pump.flow_rate} liters/minute")
    print(f"Water pumped in {hours_to_pump_3} hours: {water_pumped_3:.2f} cubic meters")

   
    water_pumped_invalid = my_pump.calculate_water_pumped(-1)
    print(f"Water pumped with invalid time: {water_pumped_invalid:.2f} cubic meters")
