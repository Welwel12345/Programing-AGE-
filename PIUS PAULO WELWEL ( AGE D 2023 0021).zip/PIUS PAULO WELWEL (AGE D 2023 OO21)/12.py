class Tractor:

    def __init__(self, model, horsepower, fuel_capacity):

        self.model = model
        self.horsepower = horsepower
        self.fuel_capacity = fuel_capacity

    def display_info(self):
       
        print(f"--- Tractor Information ---")
        print(f"Model: {self.model}")
        print(f"Horsepower: {self.horsepower} HP")
        print(f"Fuel Capacity: {self.fuel_capacity} Liters")
        print(f"--------------------------")


my_tractor = Tractor("Massey Ferguson 240", 45, 54.5)


my_tractor.display_info()
