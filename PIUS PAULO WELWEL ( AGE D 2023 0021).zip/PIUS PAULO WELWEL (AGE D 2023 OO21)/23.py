class Crop:
    def get_water_needs(self):
        return "Regular water required."
class Sugarcane(Crop):
    def get_water_needs(self):
        return "High water requirement."
class Sorghum(Crop):
    def get_water_needs(self):
        return "Low water requirement (drought resistant)."
crops = [Sugarcane(), Sorghum()]
for crop in crops:
    print(crop.get_water_needs())
