
crop_nutrients = {
    'Maize': {'N': 120, 'P': 60, 'K': 60},
    'Rice': {'N': 100, 'P': 50, 'K': 50},
    'Wheat': {'N': 150, 'P': 70, 'K': 70},
    'Soybean': {'N': 80, 'P': 40, 'K': 40},
    'Potato': {'N': 110, 'P': 55, 'K': 120} 
}

def get_nutrient_requirement():
  
    print("Welcome to the Crop Nutrient Lookup tool!")
    print("Available crops:", ", ".join(crop_nutrients.keys()))

    while True:
        
        crop_name = input("Enter the crop name (e.g., Maize): ").strip().title()

     
        if crop_name in crop_nutrients:
            break 
        else:
            print(f"Error: '{crop_name}' is not a valid crop name. Please try again.")
            print("Available crops:", ", ".join(crop_nutrients.keys()))

    print(f"\nAvailable nutrients for {crop_name}:", ", ".join(crop_nutrients[crop_name].keys()))

    while True:
       
        nutrient = input("Enter the nutrient (e.g., N, P, K): ").strip().upper()

       
        if nutrient in crop_nutrients[crop_name]:
            break 
        else:
            print(f"Error: '{nutrient}' is not a valid nutrient for {crop_name}. Please try again.")
            print(f"Available nutrients for {crop_name}:", ", ".join(crop_nutrients[crop_name].keys()))

    
    required_amount = crop_nutrients[crop_name][nutrient]
    print(f"\nFor {crop_name}, the required amount of {nutrient} is: {required_amount} kg/ha.")
if __name__ == "__main__":
    get_nutrient_requirement()
