class FarmEquipment:
    def __init__(self, name, purchase_price):
        self.name = name
        self.purchase_price = purchase_price
class Tractor(FarmEquipment):
    def __init__(self, name, purchase_price, horsepower):
        super().__init__(name, purchase_price)
        self.horsepower = horsepower
class Harvester(FarmEquipment):
    def __init__(self, name, purchase_price, cutting_width):
        super().__init__(name, purchase_price)
        self.cutting_width = cutting_width
tractor = Tractor("MF 240", 20000000, 50)
harvester = Harvester("JD", 30000000, 4.5)
print(f"Tractor Horsepower: {tractor.horsepower}")
print(f"Harvester Cutting Width: {harvester.cutting_width}")
