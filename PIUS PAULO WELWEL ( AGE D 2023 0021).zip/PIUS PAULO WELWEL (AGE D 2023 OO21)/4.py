import numpy as np


ph_values = np.array([6.2, 6.5, 5.8, 7.1, 6.0, 5.5, 6.8, 6.3, 5.9, 6.6])

print(f"Original pH values: {ph_values}")


average_ph = np.mean(ph_values)
print(f"\n1. Average pH: {average_ph:.2f}")

acidic_locations_count = np.sum(ph_values < 6.0)
print(f"2. Number of locations with acidic soil (pH < 6.0): {acidic_locations_count}")


is_acidic = ph_values < 6.0
is_neutral = (ph_values >= 6.0) & (ph_values <= 7.0)
is_alkaline = ph_values > 7.0

ph_categories = np.empty(ph_values.shape, dtype='U10') 
ph_categories[is_acidic] = 'Acidic'
ph_categories[is_neutral] = 'Neutral'
ph_categories[is_alkaline] = 'Alkaline'

print(f"\n3. Categorized pH values:")
for i in range(len(ph_values)):
    print(f"  Location {i+1}: pH {ph_values[i]:.1f} -> {ph_categories[i]}")

